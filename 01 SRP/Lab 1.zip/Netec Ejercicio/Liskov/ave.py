class Ave:
    def hacer_sonido(self):
        return "Ave haciendo sonido"