from ave import Ave

class AveNoVoladora(Ave):
    def caminar(self):
        return "Estoy caminando"