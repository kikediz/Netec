from ave import Ave 
class Pinguino(Ave): 
    def volar(self): 
        raise NotImplementedError("Los pinginos no pueden volar")