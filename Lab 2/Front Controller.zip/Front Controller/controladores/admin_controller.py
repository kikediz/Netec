class AdminController:
    def dashboard(self): 
        return "Panel de Administracin"
    
    def configuraciones(self): 
        return "Configuraciones del Sistema"