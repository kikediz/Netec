class Descanso: 
    def tomar_descanso(self): 
        raise NotImplementedError("Este mtodo debe ser implementado por las subclases")