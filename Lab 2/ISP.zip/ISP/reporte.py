class Reporte: 
    def reportar(self): 
        raise NotImplementedError("Este mtodo debe ser implementado por las subclases")