class Trabajo: 
    def trabajar(self): 
        raise NotImplementedError("Este mtodo debe ser implementado por las subclases")