# Gestor-de-tareas
Gestor de tareas

Para instalar las dependencias primero ejecuta:

```python
pip install -r requirements.txt
```

Para correr el proyecto, debes ubicarte en la Raíz, al nivel de [Controller.py](./Controller.py)

y debes ejecutar en la terminal

```bash
#!/bin/bash

flask --app Controller run --debug
```
